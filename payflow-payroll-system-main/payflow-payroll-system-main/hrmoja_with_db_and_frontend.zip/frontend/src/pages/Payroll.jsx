
export default function Payroll() {
  return (
    <div>
      <h1>Payroll</h1>
      <p>Salary, Tax & Payslip Management</p>
    </div>
  );
}
