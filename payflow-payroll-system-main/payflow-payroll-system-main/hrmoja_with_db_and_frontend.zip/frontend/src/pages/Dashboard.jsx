
export default function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Company overview & stats</p>
    </div>
  );
}
