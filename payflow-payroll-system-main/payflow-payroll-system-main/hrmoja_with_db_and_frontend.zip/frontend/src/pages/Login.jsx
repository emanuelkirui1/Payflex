
export default function Login() {
  return (
    <div>
      <h1>Login</h1>
      <input placeholder="Email" />
      <input type="password" placeholder="Password" />
      <button>Login</button>
    </div>
  );
}
